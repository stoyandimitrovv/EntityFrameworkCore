﻿namespace P03_FootballBetting.Data
{
    public class Config
    {
        public const string ConnectionString = @"Server=STOYAN\SQLEXPRESS;Database=Bet377;Integrated Security=True";
    }
}
